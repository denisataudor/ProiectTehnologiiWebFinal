var express=require("express");
var bodyParser = require("body-parser");

var app=express();
app.use(bodyParser.json());

var nodeadmin = require('nodeadmin');
app.use(nodeadmin(app));

//access static files
app.use(express.static('public'))
app.use('/nodeadmin', express.static('admin'))

app.use(express.json());       
app.use(express.urlencoded()); 

app.get('/monitorizare-firma',function(req,res){
  res.status(200).send([]);
});
/*global Firme*/
app.get('/monitorizare-firma/Firme/1', function(request, response) {
    Firme.findAll().then(function(firme){
        response.status(200).send(firme)
    })
        
})

app.get('/monitorizare-firma/Firme/1/:IdFirma', function(request, response) {
    Firme.findOne({where: {IdFirma:request.params.IdFirma}}).then(function(firma) {
        if(firma) {
            response.status(200).send(firma)
        } else {
            response.status(404).send()
        }
    })
})

app.post('/monitorizare-firma/Firme/1', function(request, response) {
    Firme.create(request.body).then(function(firma) {
        response.status(201).send(firma)
    })
})

app.put('/monitorizare-firma/Firme/1/:IdFirma', function(request, response) {
    Firme.findById(request.params.IdFirma).then(function(firma) {
        if(firma) {
            firma.update(request.body).then(function(firma){
                response.status(201).send(firma)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/monitorizare-firma/Firme/1/:IdFirma', function(request, response) {
    Firme.findById(request.params.IdFirma).then(function(firma) {
        if(firma) {
            firma.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

/*global Postari*/
app.get('/monitorizare-firma/Postari/1', function(request, response) {
    Postari.findAll().then(
            function(postari) {
                response.status(200).send(postari)
            }
        )
})

app.get('/monitorizare-firma/Postari/1/:IdPostare', function(request, response) {
    Postari.findOne({where: {IdFirma:request.params.IdFirma}}).then(function(postare) {
        if(postare) {
            response.status(200).send(postare)
        } else {
            response.status(404).send()
        }
    })
})

app.post('/monitorizare-firma/Postari/1', function(request, response) {
    Postari.create(request.body).then(function(postare) {
        response.status(201).send(postare)
    })
})

app.put('/monitorizare-firma/Postari/1/:IdPostare', function(request, response) {
    Postari.findById(request.params.IdFirma).then(function(postare) {
        if(postare) {
            postare.update(request.body).then(function(postare){
                response.status(201).send(postare)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/monitorizare-firma/Postari/1/:IdPostare', function(request, response) {
    Postari.findById(request.params.IdFirma).then(function(postare) {
        if(postare) {
            postare.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.listen(process.env.PORT);
